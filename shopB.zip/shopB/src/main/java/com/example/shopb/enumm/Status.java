package com.example.shopb.enumm;

public enum Status {

    Принят,Оформлен,Ожидает,Получен

}
