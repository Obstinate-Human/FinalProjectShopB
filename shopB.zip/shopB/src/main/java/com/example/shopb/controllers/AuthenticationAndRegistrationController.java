package com.example.shopb.controllers;

import com.example.shopb.Util.PersonValidator;
import com.example.shopb.models.Person;
import com.example.shopb.models.Product;
import com.example.shopb.repositories.CategoryRepository;
import com.example.shopb.services.PersonService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class AuthenticationAndRegistrationController {
    private final PersonValidator personValidator;
    private final PersonService personService;

    public AuthenticationAndRegistrationController(PersonValidator personValidator, PersonService personService, CategoryRepository categoryRepository) {
        this.personValidator = personValidator;
        this.personService = personService;
    }

    @GetMapping("/authentication")
    public String login(){
        return "authentication";
    }

    @GetMapping("/registration")
    public String registration(Model model){
        model.addAttribute("person", new Person());
        return "registration";
    }
    @PostMapping("/registration")
    public String resultRegistration(@ModelAttribute("person") @Valid Person person, BindingResult bindingResult){
        personValidator.validate(person, bindingResult);
        if(bindingResult.hasErrors()){
            return "registration";
        }
        personService.register(person);
        return "redirect:/product";//переходим после регистрации
    }


}
