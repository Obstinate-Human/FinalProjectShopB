package com.example.shopb.config;


import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
//Нужен для сканирования пэкэджа util
@Configuration
@ComponentScan("com.example.shopb.Util")
public class SpringConfig {

}
