package com.example.shopb.controllers;


import com.example.shopb.enumm.Status;
import com.example.shopb.models.Order;
import com.example.shopb.repositories.OrderRepository;
import com.example.shopb.services.OrderService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class OrderController {

    private final OrderRepository orderRepository;

    private final OrderService orderService;

    public OrderController(OrderRepository orderRepository, OrderService orderService) {
        this.orderRepository = orderRepository;
        this.orderService = orderService;
    }

    //поиск по 4-мм цифрам
    @PostMapping("/orderAdmin/search")
    public String ordertSearch(@RequestParam("search") String search, Model model){
        model.addAttribute("orders", orderService.getAllOrder());
        model.addAttribute("search_order", orderRepository.findOrderByPartOfNumber(search));
        model.addAttribute("value_searchOrder", search);
        return "/orderAdmin";
    }

    //Подробная информация о заказе и изменение его статуса
    @GetMapping("/admin/order/{id}")
    public String orderInfo(@PathVariable("id") int id, Model model) {
        model.addAttribute("order", orderService.getOrderById(id));
        model.addAttribute("status", Status.values());
        return "/orderInfo";
    }

    //Изменение статуса заказа на странице с заказами
    @PostMapping("/admin/order/{id}")
    public String ChangeOrderStatus(@ModelAttribute("status") Status status,
                                    @PathVariable("id") int id)
    {
        Order order = orderService.getOrderById(id); //получаем объект заказа из БД
        order.setStatus(status); //меняем статус на выбранный в селекте
        orderService.updateOrder(id, order); //обновляем данные заказа в БД
        return "redirect:/admin/order/{id}";
    }


}
