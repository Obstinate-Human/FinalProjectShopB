package com.example.shopb.config;


import com.example.shopb.services.PersonDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfiguration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig  {

   private final PersonDetailsService personDetailsService;
    //определяем метод хэширования паролей хэш-функцией BCrypt
   @Bean
   public PasswordEncoder getPasswordEncoder(){
       return new BCryptPasswordEncoder();
   }

    //HttpSecurity отвечет за объект аутентификации
    @Bean
   public SecurityFilterChain filterChain(HttpSecurity http) throws Exception{

    http
            // указываем, что все страницы должны быть защищены аутентификацией
            .authorizeHttpRequests()
            .requestMatchers("/admin", "/orderAdmin").hasRole("ADMIN")
            .requestMatchers("/authentication", "/registration","/error", "/resources/**", "/static/**", "/css/**", "/js/**", "/img/**", "/product", "/product/info/{id}", "product/search").permitAll()
            .anyRequest().hasAnyRole("USER","ADMIN")
            .and()
            //указываем какой url запрос будет отправляться при заходе на защищенные страницы
            .formLogin().loginPage("/authentication")
            //указываем на какой адрес будут отправляться данные с формы.
            .loginProcessingUrl("/process_login")
            //Указываем на какой url необходимо направить пользователя после успешной аутентификации. Вторым аргументом указывается true чтобы перенаправление шло в любом случае после успешной аутентификации
            .defaultSuccessUrl("/product", true)
            // Указываем, куда перенаправлять пользователя при неудачной аутентификации.
            .failureUrl("/authentication?error")
            .and()
            .logout().logoutUrl("/logout").logoutSuccessUrl("/authentication");//страница, куда выходим после logout
    return http.build();
   }

   @Autowired
    public SecurityConfig(PersonDetailsService personDetailsService) {
        this.personDetailsService = personDetailsService;
    }
    //Указываем, что аутентификация приложения будет осуществляться с помощью базовых настроек SS: authenticationManagerBuilder
    protected void configure(AuthenticationManagerBuilder authenticationManagerBuilder) throws Exception {
        //добавляем хэширование пароля при аутентификации
        authenticationManagerBuilder.userDetailsService(personDetailsService)
                .passwordEncoder(getPasswordEncoder());
    }
}
